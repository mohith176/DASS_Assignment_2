"""
Gobblet Jr. is a two-player strategy game where players take turns placing pieces on a 3x3 board.
The goal is
- to get 4 pieces of the same color in a row (horizontally, vertically, or diagonally) to win
- to prevent the opponent from making a winning move
- to avoid exposing a winning move for the opponent
"""
import pygame  # pylint: disable=no-member
import sys
QUIT = pygame.QUIT  # pylint: disable=no-member
MOUSEBUTTONDOWN = pygame.MOUSEBUTTONDOWN  # pylint: disable=no-member
MOUSEBUTTONUP = pygame.MOUSEBUTTONUP  # pylint: disable=no-member

# Initialize pygame
pygame.init()  # pylint: disable=no-member


# Constants
WIDTH, HEIGHT = 800, 800  # Increased size for better layout
BOARD_SIZE = 3
SQUARE_SIZE = 140  # Slightly larger squares
MARGIN = (WIDTH - (BOARD_SIZE * SQUARE_SIZE)) // 2  # Center the board horizontally
TOP_MARGIN = 120  # Space at the top
PIECE_SIZES = [35, 55, 75]  # Slightly larger pieces
RED = (220, 20, 60)
YELLOW = (255, 215, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (128, 128, 128)
LIGHT_GRAY = (240, 240, 240)  # Lighter background
BOARD_COLOR = (245, 222, 179)  # Tan board color

# Set up the display
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Gobblet Jr.')
clock = pygame.time.Clock()

"""
Gobblet Jr. is a two-player strategy game where players take turns placing pieces on a 3x3 board.
The goal is
- to get 4 pieces of the same color in a row (horizontally, vertically, or diagonally) to win
- to prevent the opponent from making a winning move
- to avoid exposing a winning move for the opponent
"""
class Piece:
    """
    A piece has a color and size (small, medium, or large).
    It can be placed on the board or held by a player.
    """
    def __init__(self, color, size):
        self.color = color
        self.size = size  # 0: small, 1: medium, 2: large
        self.radius = PIECE_SIZES[size]
        self.rect = pygame.Rect(0, 0, self.radius*2, self.radius*2)
        self.dragging = False
        self.on_board = False
        self.position = None

    def draw(self, x, y):
        """
        Draw the piece at the given position.
        If the piece is being dragged, draw a shadow effect.
        """
        # Shadow effect for dragging
        if self.dragging:
            shadow_rect = pygame.Rect(x - self.radius + 5, y - self.radius + 5, self.radius*2
                                      , self.radius*2)
            pygame.draw.ellipse(screen, GRAY, shadow_rect)

        # Draw the piece
        piece_rect = pygame.Rect(x - self.radius, y - self.radius, self.radius*2, self.radius*2)
        pygame.draw.ellipse(screen, self.color, piece_rect)
        pygame.draw.ellipse(screen, BLACK, piece_rect, 2)  # Border

    def contains_point(self, point):
        """
        Check if the piece contains the given point.
        This is used to determine if the piece is clicked or dragged.
        """
        dx = point[0] - self.rect.centerx
        dy = point[1] - self.rect.centery
        return (dx**2 + dy**2) <= self.radius**2

class Board:
    """
    The game board consists of a 3x3 grid where pieces can be placed.
    Players take turns placing pieces on the board to get 4 in a row.
    """
    def __init__(self):
        self.grid = [[[] for _ in range(BOARD_SIZE)] for _ in range(BOARD_SIZE)]
        self.selected_piece = None
        self.current_player = RED
        self.game_over = False
        self.winner = None
        self.history = []
        self.future_moves = []

        # Initialize pieces
        self.pieces = []
        for color in [RED, YELLOW]:
            for size in [2, 2, 1, 1, 0, 0]:  # 2 large, 2 medium, 2 small
                self.pieces.append(Piece(color, size))

    def draw(self):
        """
        Draw the game board, pieces, and controls.
        """
        # Draw board background
        pygame.draw.rect(screen, BOARD_COLOR,
                        (MARGIN, TOP_MARGIN,
                        BOARD_SIZE*SQUARE_SIZE,
                        BOARD_SIZE*SQUARE_SIZE))

        # Draw grid lines
        for i in range(BOARD_SIZE + 1):
            # Horizontal lines
            pygame.draw.line(screen, BLACK,
                (MARGIN, TOP_MARGIN + i*SQUARE_SIZE),
                (MARGIN + BOARD_SIZE*SQUARE_SIZE, TOP_MARGIN + i*SQUARE_SIZE), 2)
            # Vertical lines
            pygame.draw.line(screen, BLACK,
                (MARGIN + i*SQUARE_SIZE, TOP_MARGIN),
                (MARGIN + i*SQUARE_SIZE, TOP_MARGIN + BOARD_SIZE*SQUARE_SIZE), 2)

        # Draw pieces on the board
        for row in range(BOARD_SIZE):
            for col in range(BOARD_SIZE):
                stack = self.grid[row][col]
                if stack:
                    x = MARGIN + col * SQUARE_SIZE + SQUARE_SIZE // 2
                    y = TOP_MARGIN + row * SQUARE_SIZE + SQUARE_SIZE // 2
                    stack[-1].rect.center = (x, y)
                    stack[-1].draw(x, y)

        # Draw unused pieces
        self.arrange_unused_pieces()

        # Draw dragging piece on top
        if self.selected_piece and self.selected_piece.dragging:
            pos = pygame.mouse.get_pos()
            self.selected_piece.draw(pos[0], pos[1])

        # Draw current player indicator
        self.draw_player_indicator()

        # Draw control buttons
        self.draw_controls()

        # Draw game over message
        if self.game_over:
            self.draw_game_over()

    def arrange_unused_pieces(self):
        """
        Arrange unused pieces in the piece holders.
        """
        # Draw piece holder backgrounds
        pygame.draw.rect(screen, RED, (50, TOP_MARGIN, 80, 500), 0, 10)
        pygame.draw.rect(screen, YELLOW, (WIDTH - 130, TOP_MARGIN, 80, 500), 0, 10)

        # Draw text labels for the piece holders
        font = pygame.font.SysFont('Arial', 20)
        red_text = font.render("RED", True, WHITE)
        yellow_text = font.render("YELLOW", True, BLACK)
        screen.blit(red_text, (65, TOP_MARGIN + 10))
        screen.blit(yellow_text, (WIDTH - 115, TOP_MARGIN + 10))

        # Group pieces by size for better organization
        red_pieces = {0: [], 1: [], 2: []}
        yellow_pieces = {0: [], 1: [], 2: []}

        for piece in self.pieces:
            if not piece.on_board and piece is not self.selected_piece:
                if piece.color == RED:
                    red_pieces[piece.size].append(piece)
                else:  # YELLOW
                    yellow_pieces[piece.size].append(piece)

        # Draw red pieces
        y_offset = TOP_MARGIN + 50
        for size in [2, 1, 0]:  # Draw largest first
            for i, piece in enumerate(red_pieces[size]):
                x = 90
                y = y_offset + i * 60
                piece.rect.center = (x, y)
                piece.draw(x, y)
            y_offset += len(red_pieces[size]) * 60 + 30

        # Draw yellow pieces
        y_offset = TOP_MARGIN + 50
        for size in [2, 1, 0]:  # Draw largest first
            for i, piece in enumerate(yellow_pieces[size]):
                x = WIDTH - 90
                y = y_offset + i * 60
                piece.rect.center = (x, y)
                piece.draw(x, y)
            y_offset += len(yellow_pieces[size]) * 60 + 30

    def draw_player_indicator(self):
        """
        Draw the current player indicator at the top of the screen.
        """
        # Draw whose turn it is
        font = pygame.font.SysFont('Arial', 28)
        text = font.render("Current Player:", True, BLACK)
        screen.blit(text, (WIDTH//2 - 120, 50))

        # Draw colored circle for current player
        pygame.draw.circle(screen, self.current_player, (WIDTH//2 + 50, 50), 20)
        pygame.draw.circle(screen, BLACK, (WIDTH//2 + 50, 50), 20, 1)

    def draw_controls(self):
        """
        Draw the rewind and forward buttons at the bottom of the screen.
        """
        # Control panel background
        pygame.draw.rect(screen, WHITE, (WIDTH//2 - 150, HEIGHT - 80, 300, 60), 0, 10)

        # Rewind button
        pygame.draw.rect(screen, LIGHT_GRAY, (WIDTH//2 - 120, HEIGHT - 70, 80, 40), 0, 5)
        font = pygame.font.SysFont('Arial', 24)
        text = font.render("< Undo", True, BLACK)
        screen.blit(text, (WIDTH//2 - 110, HEIGHT - 65))

        # Forward button
        pygame.draw.rect(screen, LIGHT_GRAY, (WIDTH//2 + 40, HEIGHT - 70, 80, 40), 0, 5)
        text = font.render("Redo >", True, BLACK)
        screen.blit(text, (WIDTH//2 + 50, HEIGHT - 65))

    def draw_game_over(self):
        """
        Draw the game over panel with the winner and play again button.
        """
        s = pygame.Surface((WIDTH, HEIGHT))
        s.set_alpha(180)
        s.fill(WHITE)
        screen.blit(s, (0, 0))

        # Game over panel
        pygame.draw.rect(screen, WHITE, (WIDTH//2 - 150, HEIGHT//2 - 100, 300, 200), 0, 15)
        pygame.draw.rect(screen, BLACK, (WIDTH//2 - 150, HEIGHT//2 - 100, 300, 200), 2, 15)

        font = pygame.font.SysFont('Arial', 42)
        if self.winner == RED:
            text = font.render("Red Wins!", True, RED)
        else:
            text = font.render("Yellow Wins!", True, YELLOW)

        screen.blit(text, (WIDTH//2 - text.get_width()//2, HEIGHT//2 - 60))

        # Play again button
        pygame.draw.rect(screen, LIGHT_GRAY, (WIDTH//2 - 80, HEIGHT//2 + 20, 160, 50), 0, 10)
        font = pygame.font.SysFont('Arial', 24)
        text = font.render("Play Again", True, BLACK)
        screen.blit(text, (WIDTH//2 - text.get_width()//2, HEIGHT//2 + 35))

    def handle_click(self, pos):
        """
        Handle mouse click events.
        If a piece is clicked, select it for dragging.
        If the rewind or forward button is clicked, perform the corresponding action.
        If the game is over, allow the player to play again.
        """
        if self.game_over:
            # Check if Play Again button is clicked
            if (WIDTH//2 - 80 <= pos[0] <= WIDTH//2 + 80 and
                HEIGHT//2 + 20 <= pos[1] <= HEIGHT//2 + 70):
                self.__init__()
            return

        # Check if rewind button is clicked
        if WIDTH//2 - 120 <= pos[0] <= WIDTH//2 - 40 and HEIGHT - 70 <= pos[1] <= HEIGHT - 30:
            self.rewind()
            return

        # Check if forward button is clicked
        if WIDTH//2 + 40 <= pos[0] <= WIDTH//2 + 120 and HEIGHT - 70 <= pos[1] <= HEIGHT - 30:
            self.forward()
            return

        # First try to select a piece from the board
        for row in range(BOARD_SIZE):
            for col in range(BOARD_SIZE):
                stack = self.grid[row][col]
                if (stack and stack[-1].contains_point(pos) and
                    stack[-1].color == self.current_player):
                    self.selected_piece = stack[-1]
                    self.selected_piece.dragging = True
                    # Remove piece from board temporarily
                    self.grid[row][col].pop()
                    self.selected_piece.on_board = False
                    self.selected_piece.position = (row, col)
                    return

        # If no piece selected from board, try unused pieces
        for piece in self.pieces:
            if (not piece.on_board and
                piece.contains_point(pos) and piece.color == self.current_player):
                self.selected_piece = piece
                self.selected_piece.dragging = True
                return

    def handle_release(self, pos):
        """
        Handle mouse release events.
        If a piece is being dragged, check if it can be placed on the board.
        If the piece is placed, check for a win or switch players.
        """
        if not self.selected_piece or not self.selected_piece.dragging:
            return

        self.selected_piece.dragging = False

        # Check if released on board
        for row in range(BOARD_SIZE):
            for col in range(BOARD_SIZE):
                x = MARGIN + col * SQUARE_SIZE + SQUARE_SIZE // 2
                y = TOP_MARGIN + row * SQUARE_SIZE + SQUARE_SIZE // 2

                if (x - SQUARE_SIZE//2 <= pos[0] <= x + SQUARE_SIZE//2 and
                    y - SQUARE_SIZE//2 <= pos[1] <= y + SQUARE_SIZE//2):

                    # Cannot place piece in same position
                    if self.selected_piece.position == (row, col):
                        # Put piece back where it was
                        if self.selected_piece.position:
                            r, c = self.selected_piece.position
                            self.grid[r][c].append(self.selected_piece)
                            self.selected_piece.on_board = True
                        return

                    # Check if can place/move piece
                    if self.can_place_piece(row, col):
                        # Save current state for undo
                        self.save_state()

                        # Place piece on board
                        self.grid[row][col].append(self.selected_piece)
                        self.selected_piece.on_board = True
                        self.selected_piece.position = (row, col)

                        # Check for exposure rule win
                        if self.check_exposure_rule():
                            self.game_over = True
                            self.winner = YELLOW if self.current_player == RED else RED
                        # Check for regular win
                        elif self.check_win():
                            self.game_over = True
                            self.winner = self.current_player
                        else:
                            # Switch player
                            self.current_player = YELLOW if self.current_player == RED else RED

                        self.selected_piece = None
                        return

        # If not placed on board or invalid move, return piece to original position
        if self.selected_piece.position:
            row, col = self.selected_piece.position
            self.grid[row][col].append(self.selected_piece)
            self.selected_piece.on_board = True

        self.selected_piece = None

    def can_place_piece(self, row, col):
        """
        Check if the selected piece can be placed on the given board position.
        The piece must be smaller than the top piece in the stack or the space must be empty.
        """
        # Check if space is empty or has smaller piece on top
        if not self.grid[row][col]:
            return True

        top_piece = self.grid[row][col][-1]
        return self.selected_piece.size > top_piece.size

    def check_win(self):
        """
        Check if the current player has won the game.
        A player wins if they have 4 pieces of the same color in a row.
        """
        # Check rows
        for row in range(BOARD_SIZE):
            if self.check_line([self.grid[row][col] for col in range(BOARD_SIZE)]):
                return True

        # Check columns
        for col in range(BOARD_SIZE):
            if self.check_line([self.grid[row][col] for row in range(BOARD_SIZE)]):
                return True

        # Check diagonals
        if self.check_line([self.grid[i][i] for i in range(BOARD_SIZE)]):
            return True
        if self.check_line([self.grid[i][BOARD_SIZE-1-i] for i in range(BOARD_SIZE)]):
            return True

        return False

    def check_line(self, line):
        """
        Check if a line of pieces contains 4 pieces of the same color.
        """
        # Check if all visible pieces in line are same color
        visible_pieces = [stack[-1] for stack in line if stack]
        if len(visible_pieces) < BOARD_SIZE:
            return False

        return all(piece.color == self.current_player for piece in visible_pieces)

    def check_exposure_rule(self):
        """
        Check if the current player has exposed a winning move for the opponent.
        This is a special rule to prevent players from making moves that would 
        allow the opponent to win.
        """
        # If piece was moved from board (not newly placed)
        if not self.selected_piece.position:
            return False

        orig_row, orig_col = self.selected_piece.position

        # Temporarily remove piece from destination
        current_row, current_col = self.selected_piece.position
        self.grid[current_row][current_col].pop()

        # Check if opponent has winning line that includes original position
        opponent = YELLOW if self.current_player == RED else RED
        self.current_player = opponent

        exposed_win = self.check_win()

        # Restore piece and current player
        self.grid[current_row][current_col].append(self.selected_piece)
        self.current_player = RED if opponent == YELLOW else YELLOW

        return exposed_win

    def save_state(self):
        """
        Save the current board state to the history list.
        """
        # Clear future moves if we're making a new move after rewind
        if self.future_moves:
            self.future_moves = []

        # Save current board state to history
        state = {
            'grid': [[stack.copy() for stack in row] for row in self.grid],
            'current_player': self.current_player,
            'pieces': [piece for piece in self.pieces]
        }
        self.history.append(state)

    def rewind(self):
        """
        Rewind the game state to the previous move.
        """
        if not self.history:
            return

        # Add current state to future_moves
        state = {
            'grid': [[stack.copy() for stack in row] for row in self.grid],
            'current_player': self.current_player,
            'pieces': [piece for piece in self.pieces]
        }
        self.future_moves.append(state)

        # Restore previous state
        prev_state = self.history.pop()
        self.grid = prev_state['grid']
        self.current_player = prev_state['current_player']
        self.pieces = prev_state['pieces']
        self.game_over = False
        self.winner = None

    def forward(self):
        """
        Move forward in the game state to the next move.
        """
        if not self.future_moves:
            return

        # Add current state to history
        state = {
            'grid': [[stack.copy() for stack in row] for row in self.grid],
            'current_player': self.current_player,
            'pieces': [piece for piece in self.pieces]
        }
        self.history.append(state)

        # Restore future state
        next_state = self.future_moves.pop()
        self.grid = next_state['grid']
        self.current_player = next_state['current_player']
        self.pieces = next_state['pieces']

def main():
    """
    Main game loop.
    """
    board = Board()

    # Main game loop
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == MOUSEBUTTONDOWN:
                if event.button == 1:  # Left click
                    board.handle_click(event.pos)
            elif event.type == MOUSEBUTTONUP:
                if event.button == 1:  # Left click release
                    board.handle_release(event.pos)

        # Draw everything
        screen.fill(LIGHT_GRAY)
        board.draw()

        pygame.display.flip()
        clock.tick(60)

if __name__ == "__main__":
    main()
