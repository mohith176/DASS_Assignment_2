import pytest
import os
import json
import sys
import time
from unittest.mock import patch, MagicMock
from datetime import datetime

# Add the src directory to the Python path
src_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../src'))
sys.path.insert(0, src_dir)

# Import the modules
from app import UserDatabase, DollmartApp
from items import ItemDatabase
from cart import CartDatabase
from coupons import CouponDatabase

# Test data
TEST_USER_DB = 'test_users.json'
TEST_ITEM_DB = 'test_items.json'
TEST_CART_DB = 'test_cart.json'
TEST_COUPON_DB = 'test_coupons.json'

# Fixture for user database
@pytest.fixture
def user_db():
    # Create a test user database
    with open(TEST_USER_DB, 'w') as f:
        json.dump({
            "individual_customers": [
                {"username": "testuser", "password": "testpass"}
            ],
            "retail_store_customers": [
                {"username": "testretail", "password": "testpass"}
            ]
        }, f)
    
    db = UserDatabase(TEST_USER_DB)
    yield db
    
    # Cleanup
    if os.path.exists(TEST_USER_DB):
        os.remove(TEST_USER_DB)

# Fixture for item database
@pytest.fixture
def item_db():
    # Create a test item database
    with open(TEST_ITEM_DB, 'w') as f:
        json.dump({
            "items": [
                {
                    "name": "TestItem",
                    "category": "TestCategory",
                    "individual_price": 10.0,
                    "retail_price": 8.0
                },
                {
                    "name": "AnotherItem",
                    "category": "AnotherCategory",
                    "individual_price": 20.0,
                    "retail_price": 15.0
                }
            ]
        }, f)
    
    db = ItemDatabase(TEST_ITEM_DB)
    yield db
    
    # Cleanup
    if os.path.exists(TEST_ITEM_DB):
        os.remove(TEST_ITEM_DB)

# Fixture for cart database
@pytest.fixture
def cart_db(item_db):
    # Create a test cart database
    with open(TEST_CART_DB, 'w') as f:
        json.dump({
            "testuser": {
                "TestItem": 2
            }
        }, f)
    
    db = CartDatabase(TEST_CART_DB)
    yield db
    
    # Cleanup
    if os.path.exists(TEST_CART_DB):
        os.remove(TEST_CART_DB)

# Fixture for coupon database
@pytest.fixture
def coupon_db():
    # Create a test coupon database
    with open(TEST_COUPON_DB, 'w') as f:
        json.dump({
            "coupons": [
                {
                    "discount": 20,
                    "status": "Available",
                    "username": "testuser"
                }
            ]
        }, f)
    
    db = CouponDatabase(TEST_COUPON_DB)
    yield db
    
    # Cleanup
    if os.path.exists(TEST_COUPON_DB):
        os.remove(TEST_COUPON_DB)

# Test user database functionality
class TestUserDatabase:
    def test_load_user_data(self, user_db):
        # Test loading user data
        data = user_db.data
        assert "individual_customers" in data
        assert "retail_store_customers" in data
        assert len(data["individual_customers"]) == 1
        assert len(data["retail_store_customers"]) == 1
    
    def test_add_user(self, user_db):
        # Test adding a new individual user
        user_db.add_user("individual", "newuser", "newpass")
        assert any(user["username"] == "newuser" for user in user_db.data["individual_customers"])
        
        # Test adding a new retail user
        user_db.add_user("retail", "newretail", "newpass")
        assert any(user["username"] == "newretail" for user in user_db.data["retail_store_customers"])
    
    def test_authenticate_user(self, user_db):
        # Test successful authentication
        assert user_db.authenticate_user("individual", "testuser", "testpass") == True
        assert user_db.authenticate_user("retail", "testretail", "testpass") == True
        
        # Test failed authentication
        assert user_db.authenticate_user("individual", "testuser", "wrongpass") == False
        assert user_db.authenticate_user("individual", "wronguser", "testpass") == False

# Test item database functionality
class TestItemDatabase:
    def test_load_item_data(self, item_db):
        # Test loading item data
        items = item_db.get_items()
        assert len(items) == 2
        assert items[0]["name"] == "TestItem"
        assert items[1]["name"] == "AnotherItem"
    
    def test_search_item(self, item_db):
        # Test searching items
        with patch('builtins.input', side_effect=['1', 'test', '3']):
            with patch('builtins.print') as mock_print:
                ItemDatabase.search_item("individual")
                # Check if search results are printed
                mock_print.assert_any_call("-" * 50)
    
    @patch('builtins.print')
    def test_display_items(self, mock_print, item_db):
        # Test displaying items for individual customers
        ItemDatabase.display_items("individual")
        mock_print.assert_any_call("-" * 50)
        
        # Test displaying items for retail customers
        ItemDatabase.display_items("retail")
        mock_print.assert_any_call("-" * 50)

# Test cart database functionality
class TestCartDatabase:
    def test_load_cart_data(self, cart_db):
        # Test loading cart data
        data = cart_db.data
        assert "testuser" in data
        assert "TestItem" in data["testuser"]
        assert data["testuser"]["TestItem"] == 2
    
    def test_remove_from_cart(self, cart_db):
        # Test removing items from cart
        with patch('builtins.print'):
            cart_db.remove_from_cart("testuser", "TestItem", 1)
            assert cart_db.data["testuser"]["TestItem"] == 1  # 2 - 1
        
        # Test removing all of an item
        with patch('builtins.print'):
            cart_db.remove_from_cart("testuser", "TestItem", 1)
            assert "TestItem" not in cart_db.data["testuser"]
    
    def test_view_cart_empty(self, cart_db):
        # Test viewing an empty cart
        with patch('builtins.print') as mock_print:
            cart_db.view_cart("nonexistentuser", "individual")
            mock_print.assert_any_call("Your cart is empty.")
    
    def test_empty_cart(self, cart_db):
        # Test emptying a cart
        cart_db.empty_cart("testuser")
        assert cart_db.data["testuser"] == {}

# Test coupon database functionality
class TestCouponDatabase:
    def test_load_coupon_data(self, coupon_db):
        # Test loading coupon data
        data = coupon_db.data
        assert "coupons" in data
        assert len(data["coupons"]) == 1
        assert data["coupons"][0]["discount"] == 20
    
    def test_generate_coupons(self, coupon_db):
        # Test generating coupons based on completed orders
        coupon_db.generate_coupons("newuser", 3)
        coupons = coupon_db.data["coupons"]
        assert any(c["discount"] == 20 and c["username"] == "newuser" for c in coupons)
        
        coupon_db.generate_coupons("newuser", 5)
        coupons = coupon_db.data["coupons"]
        assert any(c["discount"] == 30 and c["username"] == "newuser" for c in coupons)
        
        coupon_db.generate_coupons("newuser", 10)
        coupons = coupon_db.data["coupons"]
        assert any(c["discount"] == 50 and c["username"] == "newuser" for c in coupons)
    
    def test_get_available_coupons(self, coupon_db):
        # Test getting available coupons
        available = coupon_db.get_available_coupons("testuser")
        assert len(available) == 1
        assert available[0]["discount"] == 20
        
        # Test no available coupons
        assert len(coupon_db.get_available_coupons("nonexistentuser")) == 0
    
    def test_avail_coupon(self, coupon_db):
        # Test availing a valid coupon
        assert coupon_db.avail_coupon("testuser", 20) == True
        coupons = coupon_db.data["coupons"]
        assert coupons[0]["status"] == "Availed"
        
        # Test availing an invalid coupon
        assert coupon_db.avail_coupon("testuser", 30) == False
        assert coupon_db.avail_coupon("nonexistentuser", 20) == False

# Test DollmartApp functionality
class TestDollmartApp:
    @patch('builtins.input', side_effect=['testuser', 'testpass'])
    def test_sign_in_success(self, mock_input, user_db):
        # Create app with test user database
        app = DollmartApp()
        app.user_db = user_db
        
        # Test successful sign in
        with patch('builtins.print') as mock_print:
            with patch.object(app, 'redirect_to_homepage') as mock_redirect:
                result = app.sign_in("individual")
                assert result == True
                mock_print.assert_any_call("Sign-in successful!")
                mock_redirect.assert_called_once_with("individual", "testuser")
    
    @patch('builtins.input', side_effect=['wronguser', 'wrongpass'])
    def test_sign_in_failure(self, mock_input, user_db):
        # Create app with test user database
        app = DollmartApp()
        app.user_db = user_db
        
        # Test failed sign in
        with patch('builtins.print') as mock_print:
            result = app.sign_in("individual")
            assert result == False
            mock_print.assert_any_call("Invalid username or password.")
    
    @patch('builtins.input', side_effect=['newuser', 'newpass'])
    def test_sign_up(self, mock_input, user_db):
        # Create app with test user database
        app = DollmartApp()
        app.user_db = user_db
        
        # Test sign up
        with patch('builtins.print') as mock_print:
            with patch.object(app, 'redirect_to_homepage') as mock_redirect:
                app.sign_up("individual")
                mock_print.assert_any_call("Sign-up successful!")
                mock_redirect.assert_called_once_with("individual", "newuser")
                
                # Check if user was added to database
                assert any(user["username"] == "newuser" for user in user_db.data["individual_customers"])