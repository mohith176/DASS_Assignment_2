import json
import os

# Filepath for the JSON database
COUPON_DB_FILE = 'coupons.json'

class CouponDatabase:
    def __init__(self, filepath):
        self.filepath = filepath
        self.data = self.load_coupon_data()

    def load_coupon_data(self):
        if not os.path.exists(self.filepath):
            with open(self.filepath, 'w') as f:
                json.dump({"coupons": []}, f)
        
        with open(self.filepath, 'r') as f:
            return json.load(f)

    def save_coupon_data(self):
        with open(self.filepath, 'w') as f:
            json.dump(self.data, f, indent=4)

    def generate_coupons(self, username, completed_orders):
        if completed_orders >= 3 and not any(coupon["discount"] == 20 and coupon["username"] == username for coupon in self.data["coupons"]):
            self.data["coupons"].append({"discount": 20, "status": "Available", "username": username})
        if completed_orders >= 5 and not any(coupon["discount"] == 30 and coupon["username"] == username for coupon in self.data["coupons"]):
            self.data["coupons"].append({"discount": 30, "status": "Available", "username": username})
        if completed_orders >= 10 and not any(coupon["discount"] == 50 and coupon["username"] == username for coupon in self.data["coupons"]):
            self.data["coupons"].append({"discount": 50, "status": "Available", "username": username})
        self.save_coupon_data()

    def get_available_coupons(self, username):
        return [coupon for coupon in self.data["coupons"] if coupon["status"] == "Available" and coupon["username"] == username]

    def avail_coupon(self, username, discount):
        for coupon in self.data["coupons"]:
            if coupon["discount"] == discount and coupon["status"] == "Available" and coupon["username"] == username:
                coupon["status"] = "Availed"
                self.save_coupon_data()
                return True
        return False