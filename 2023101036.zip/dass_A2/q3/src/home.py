# import json
# import os
# from items import ItemDatabase
# from cart import CartDatabase
# from orders import OrderDatabase

# # Filepath for the JSON database
# USER_DB_FILE = 'users.json'
# CART_DB_FILE = 'cart.json'
# ORDER_DB_FILE = 'orders.json'

# class Home:
#     def __init__(self, user_type, username):
#         self.user_type = user_type
#         self.username = username
#         self.cart_db = CartDatabase(CART_DB_FILE)
#         self.order_db = OrderDatabase(ORDER_DB_FILE)

#     def display_homepage(self):
#         while True:
#             print(f"Welcome, {self.username}!")
#             print("1. Items")
#             print("2. View Orders")
#             print("3. View Discount Coupons")
#             print("4. Logout")
#             print("5. Exit")
#             choice = input("Enter your choice: ")

#             if choice == '1':
#                 self.view_items()
#             elif choice == '2':
#                 self.view_orders()
#             elif choice == '3':
#                 print("Displaying discount coupons... (This feature is under development)")
#             elif choice == '4':
#                 print("Logging out...")
#                 from app import DollmartApp
#                 app = DollmartApp()
#                 app.main_menu()
#                 break
#             elif choice == '5':
#                 print("Goodbye!")
#                 exit()
#             else:
#                 print("Invalid choice. Please try again.")

#     def view_items(self):
#         ItemDatabase.display_items(self.user_type)
#         self.nav_1()

#     def view_orders(self):
#         self.order_db.view_orders(self.username)

#     def nav_1(self):
#         while True:
#             print("Search_item(S)   Add_to_cart(A)   View_cart(V)   Remove_from_cart(R)    Back(B)")
#             choice = input("Enter your choice: ")
#             if choice == 'S':
#                 ItemDatabase.search_item(self.user_type)
#             elif choice == 'A':
#                 self.add_to_cart()
#                 print("cart after adding items")
#                 self.view_cart()
#                 self.nav_2()
#             elif choice == 'V':
#                 self.view_cart()
#                 self.nav_2()
#             elif choice == 'R':
#                 self.remove_from_cart()
#                 print("cart after removing items")
#                 self.view_cart()
#                 self.nav_2()
#             elif choice == 'B':
#                 break
#             else:
#                 print("Invalid choice. Please try again.")

#     def add_to_cart(self):
#         item_name = input("Enter the item name: ")
#         quantity = int(input("Enter the quantity: "))
#         self.cart_db.add_to_cart(self.username, item_name, quantity)

#     def view_cart(self):
#         self.cart_db.view_cart(self.username, self.user_type)

#     def remove_from_cart(self):
#         item_name = input("Enter the item name: ")
#         quantity = int(input("Enter the quantity: "))
#         self.cart_db.remove_from_cart(self.username, item_name, quantity)

#     def nav_2(self):
#         while True:
#             print("Home(H)  Place_order(P)  Back(B)")
#             choice = input("Enter your choice: ")
#             if choice == 'H':
#                 self.display_homepage()
#             elif choice == 'P':
#                 self.place_order()
#             elif choice == 'B':
#                 break
#             else:
#                 print("Invalid choice. Please try again.")

#     def place_order(self):
#         self.order_db.place_order(self.username, self.cart_db.data)
#         self.cart_db.empty_cart(self.username)

import json
import os
from items import ItemDatabase
from cart import CartDatabase
from orders import OrderDatabase
from coupons import CouponDatabase

# Filepath for the JSON database
USER_DB_FILE = 'users.json'
CART_DB_FILE = 'cart.json'
ORDER_DB_FILE = 'orders.json'
COUPON_DB_FILE = 'coupons.json'

class Home:
    def __init__(self, user_type, username):
        self.user_type = user_type
        self.username = username
        self.cart_db = CartDatabase(CART_DB_FILE)
        self.order_db = OrderDatabase(ORDER_DB_FILE)
        self.coupon_db = CouponDatabase(COUPON_DB_FILE)

    def display_homepage(self):
        while True:
            print(f"Welcome, {self.username}!")
            print("1. Items")
            print("2. View Orders")
            print("3. View Discount Coupons")
            print("4. Logout")
            print("5. Exit")
            choice = input("Enter your choice: ")

            if choice == '1':
                self.view_items()
            elif choice == '2':
                self.view_orders()
            elif choice == '3':
                self.view_coupons()
            elif choice == '4':
                print("Logging out...")
                break
            elif choice == '5':
                print("Goodbye!")
                exit()
            else:
                print("Invalid choice. Please try again.")

    def view_items(self):
        ItemDatabase.display_items(self.user_type)
        self.nav_1()

    def view_orders(self):
        self.order_db.view_orders(self.username)

    def view_coupons(self):
        available_coupons = self.coupon_db.get_available_coupons(self.username)
        if not available_coupons:
            print("No available coupons.")
            return
        print(f"{'Discount':<10} {'Status':<10}")
        print("-" * 20)
        for coupon in available_coupons:
            print(f"{coupon['discount']:<10} {coupon['status']:<10}")
        print("-" * 20)

    def nav_1(self):
        while True:
            print("Search_item(S)   Add_to_cart(A)   View_cart(V)   Remove_from_cart(R)    Back(B)")
            choice = input("Enter your choice: ")
            if choice == 'S':
                ItemDatabase.search_item(self.user_type)
            elif choice == 'A':
                self.add_to_cart()
                print("cart after adding items")
                self.view_cart()
                self.nav_2()
            elif choice == 'V':
                self.view_cart()
                self.nav_2()
            elif choice == 'R':
                self.remove_from_cart()
                print("cart after removing items")
                self.view_cart()
                self.nav_2()
            elif choice == 'B':
                break
            else:
                print("Invalid choice. Please try again.")

    def add_to_cart(self):
        item_name = input("Enter the item name: ")
        quantity = int(input("Enter the quantity: "))
        self.cart_db.add_to_cart(self.username, item_name, quantity)

    def view_cart(self):
        self.cart_db.view_cart(self.username, self.user_type)

    def remove_from_cart(self):
        item_name = input("Enter the item name: ")
        quantity = int(input("Enter the quantity: "))
        self.cart_db.remove_from_cart(self.username, item_name, quantity)

    def nav_2(self):
        while True:
            print("Home(H)  Place_order(P)  Back(B)")
            choice = input("Enter your choice: ")
            if choice == 'H':
                self.display_homepage()
            elif choice == 'P':
                self.place_order()
            elif choice == 'B':
                break
            else:
                print("Invalid choice. Please try again.")

    def place_order(self):
        available_coupons = self.coupon_db.get_available_coupons(self.username)
        apply_coupon = None
        if available_coupons:
            print("Available coupons:")
            for coupon in available_coupons:
                print(f"{coupon['discount']}% discount")
            use_coupon = input("Do you want to avail a coupon? (yes/no): ").strip().lower()
            if use_coupon == 'yes':
                discount = int(input("Enter the discount percentage: "))
                apply_coupon = next((coupon for coupon in available_coupons if coupon["discount"] == discount), None)
                if not apply_coupon:
                    print("Invalid coupon.")
                    return

        self.order_db.place_order(self.username, self.cart_db.data, self.user_type, apply_coupon)
        self.cart_db.empty_cart(self.username)