import json
import os

# Filepath for the JSON database
ITEM_DB_FILE = 'items.json'

class ItemDatabase:
    def __init__(self, filepath):
        self.filepath = filepath
        self.data = self.load_item_data()

    def load_item_data(self):
        if not os.path.exists(self.filepath):
            with open(self.filepath, 'w') as f:
                json.dump({"items": []}, f)
        
        with open(self.filepath, 'r') as f:
            return json.load(f)

    def get_items(self):
        return self.data["items"]

    def display_items(user_type):
        item_db = ItemDatabase(ITEM_DB_FILE)
        items = item_db.get_items()

        print(f"{'Name':<20} {'Category':<20} {'Price':<10}")
        print("-" * 50)
        for item in items:
            name = item["name"]
            category = item["category"]
            price = item["individual_price"] if user_type == "individual" else item["retail_price"]
            print(f"{name:<20} {category:<20} {price:<10}")
        print("-" * 50)

    def search_item(user_type):
        item_db = ItemDatabase(ITEM_DB_FILE)
        items = item_db.get_items()

        while True:
            print("1. Search (case insensitive)")
            print("2. Search by category")
            print("3. Back")
            choice = input("Enter your choice: ")

            if choice == '1':
                search_term = input("Enter search term: ").strip().lower()
                results = [item for item in items if search_term in item["name"].lower()]
                ItemDatabase.display_search_results(results, user_type)
            elif choice == '2':
                categories = set(item["category"] for item in items)
                print("Available categories:")
                for category in categories:
                    print(f"- {category}")
                selected_categories = input("Enter categories (comma separated): ").strip().split(',')
                selected_categories = [category.strip() for category in selected_categories if category.strip()]
                if not selected_categories:
                    results = items
                else:
                    results = [item for item in items if item["category"] in selected_categories]
                ItemDatabase.display_search_results(results, user_type)
            elif choice == '3':
                break
            else:
                print("Invalid choice. Please try again.")

    def display_search_results(results, user_type):
        print(f"{'Name':<20} {'Category':<20} {'Price':<10}")
        print("-" * 50)
        for item in results:
            name = item["name"]
            category = item["category"]
            price = item["individual_price"] if user_type == "individual" else item["retail_price"]
            print(f"{name:<20} {category:<20} {price:<10}")
        print("-" * 50)