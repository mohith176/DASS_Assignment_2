import json
import os
from home import Home

# Filepath for the JSON database
USER_DB_FILE = 'users.json'

class UserDatabase:
    def __init__(self, filepath):
        self.filepath = filepath
        self.data = self.load_user_data()

    def load_user_data(self):
        if not os.path.exists(self.filepath):
            with open(self.filepath, 'w') as f:
                json.dump({"individual_customers": [], "retail_store_customers": []}, f)
        
        with open(self.filepath, 'r') as f:
            return json.load(f)

    def save_user_data(self):
        with open(self.filepath, 'w') as f:
            json.dump(self.data, f, indent=4)

    def add_user(self, user_type, username, password):
        if user_type == "individual":
            self.data["individual_customers"].append({"username": username, "password": password})
        elif user_type == "retail":
            self.data["retail_store_customers"].append({"username": username, "password": password})
        self.save_user_data()

    def authenticate_user(self, user_type, username, password):
        if user_type == "individual":
            users = self.data["individual_customers"]
        elif user_type == "retail":
            users = self.data["retail_store_customers"]

        for user in users:
            if user["username"] == username and user["password"] == password:
                return True
        return False

class DollmartApp:
    def __init__(self):
        self.user_db = UserDatabase(USER_DB_FILE)

    def sign_up(self, user_type):
        username = input("Enter username: ")
        password = input("Enter password: ")
        self.user_db.add_user(user_type, username, password)
        print("Sign-up successful!")
        self.redirect_to_homepage(user_type, username)

    def sign_in(self, user_type):
        username = input("Enter username: ")
        password = input("Enter password: ")
        if self.user_db.authenticate_user(user_type, username, password):
            print("Sign-in successful!")
            self.redirect_to_homepage(user_type, username)
            return True
        else:
            print("Invalid username or password.")
            return False

    def redirect_to_homepage(self, user_type, username):
        home = Home(user_type, username)
        home.display_homepage()

    def main_menu(self):
        while True:
            print("Welcome to Dollmart!")
            print("Are you an Individual customer or a Retail store customer?")
            print("1. Individual customer")
            print("2. Retail store customer")
            print("3. Exit")
            choice = input("Enter your choice: ")

            if choice == '1':
                self.customer_menu("individual")
            elif choice == '2':
                self.customer_menu("retail")
            elif choice == '3':
                print("Goodbye!")
                break
            else:
                print("Invalid choice. Please try again.")

    def customer_menu(self, user_type):
        while True:
            print("1. Sign up")
            print("2. Sign in")
            print("3. Exit")
            choice = input("Enter your choice: ")

            if choice == '1':
                self.sign_up(user_type)
            elif choice == '2':
                if self.sign_in(user_type):
                    break
            elif choice == '3':
                break
            else:
                print("Invalid choice. Please try again.")

if __name__ == "__main__":
    app = DollmartApp()
    app.main_menu()