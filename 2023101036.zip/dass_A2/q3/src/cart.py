import json
import os
from items import ItemDatabase

# Filepath for the JSON database
CART_DB_FILE = 'cart.json'
ITEM_DB_FILE = 'items.json'

class CartDatabase:
    def __init__(self, filepath):
        self.filepath = filepath
        self.data = self.load_cart_data()
        self.item_db = ItemDatabase(ITEM_DB_FILE)

    def load_cart_data(self):
        if not os.path.exists(self.filepath):
            with open(self.filepath, 'w') as f:
                json.dump({}, f)
        
        with open(self.filepath, 'r') as f:
            return json.load(f)

    def save_cart_data(self):
        with open(self.filepath, 'w') as f:
            json.dump(self.data, f, indent=4)

    def add_to_cart(self, username, item_name, quantity):
        # Check if the item exists in the item database
        items = self.item_db.get_items()
        if not any(item["name"].lower() == item_name.lower() for item in items):
            print("Item not found in the database.")
            return

        if username not in self.data:
            self.data[username] = {}
        if item_name in self.data[username]:
            self.data[username][item_name] += quantity
        else:
            self.data[username][item_name] = quantity
        self.save_cart_data()
        print("Item added to cart.")

    def view_cart(self, username, user_type):
        if username not in self.data or not self.data[username]:
            print("Your cart is empty.")
            return

        items = self.item_db.get_items()
        total_price = 0
        print(f"{'Item':<20} {'Quantity':<10} {'Price':<10}")
        print("-" * 50)
        for item_name, quantity in self.data[username].items():
            item = next((item for item in items if item["name"].lower() == item_name.lower()), None)
            if item:
                price = item["individual_price"] if user_type == "individual" else item["retail_price"]
                total_price += price * quantity
                print(f"{item_name:<20} {quantity:<10} {price * quantity:<10}")
        print("-" * 50)
        print(f"{'Total Price':<30} {total_price:<10}")
        print("-" * 50)

    def remove_from_cart(self, username, item_name, quantity):
        if username not in self.data or not self.data[username]:
            print("Your cart is empty.")
            return
        if item_name not in self.data[username]:
            print("Item not found in cart.")
            return
        if self.data[username][item_name] < quantity:
            print("Invalid quantity. You cannot remove more than what is in the cart.")
            return
        self.data[username][item_name] -= quantity
        if self.data[username][item_name] == 0:
            del self.data[username][item_name]
        self.save_cart_data()
        print("Item removed from cart.")

    def empty_cart(self, username):
        if username in self.data:
            self.data[username] = {}
            self.save_cart_data()