# import json
# import os
# import time
# import threading
# from datetime import datetime

# # Filepath for the JSON database
# ORDER_DB_FILE = 'orders.json'
# CART_DB_FILE = 'cart.json'
# AGENT_DB_FILE = 'delivery_agents.json'

# class OrderDatabase:
#     def __init__(self, filepath):
#         self.filepath = filepath
#         self.data = self.load_order_data()
#         self.agent_data = self.load_agent_data()

#     def load_order_data(self):
#         if not os.path.exists(self.filepath):
#             with open(self.filepath, 'w') as f:
#                 json.dump({}, f)
        
#         with open(self.filepath, 'r') as f:
#             return json.load(f)

#     def load_agent_data(self):
#         if not os.path.exists(AGENT_DB_FILE):
#             with open(AGENT_DB_FILE, 'w') as f:
#                 json.dump({"agents": []}, f)
        
#         with open(AGENT_DB_FILE, 'r') as f:
#             return json.load(f)

#     def save_order_data(self):
#         with open(self.filepath, 'w') as f:
#             json.dump(self.data, f, indent=4)

#     def save_agent_data(self):
#         with open(AGENT_DB_FILE, 'w') as f:
#             json.dump(self.agent_data, f, indent=4)

#     def assign_delivery_agent(self):
#         for agent in self.agent_data["agents"]:
#             if agent["status"] == "Available":
#                 agent["status"] = "Unavailable"
#                 self.save_agent_data()
#                 return agent
#         return None

#     def update_order_status(self, order_id, status):
#         self.data[order_id]["status"] = status
#         self.save_order_data()

#     def complete_delivery(self, order_id, agent_id):
#         time.sleep(30)
#         self.update_order_status(order_id, "Delivered")
#         for agent in self.agent_data["agents"]:
#             if agent["id"] == agent_id:
#                 agent["status"] = "Available"
#                 self.save_agent_data()
#                 break

#     def place_order(self, username, cart_data):
#         if username not in cart_data or not cart_data[username]:
#             print("Your cart is empty. Cannot place order.")
#             return

#         agent = self.assign_delivery_agent()
#         if not agent:
#             print("Currently no delivery agent is available. Please place the order after a while.")
#             return

#         order_id = str(len(self.data) + 1)
#         order_details = {
#             "username": username,
#             "items": cart_data[username],
#             "order_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
#             "status": "Delivering",
#             "agent_id": agent["id"],
#             "agent_name": agent["name"]
#         }
#         self.data[order_id] = order_details
#         self.save_order_data()
#         print("Order placed successfully!")

#         # Start a thread to simulate delivery
#         threading.Thread(target=self.complete_delivery, args=(order_id, agent["id"])).start()

#     def view_orders(self, username):
#         user_orders = [order for order in self.data.values() if order["username"] == username]
#         if not user_orders:
#             print("No orders found.")
#             return

#         print(f"{'Order ID':<10} {'Order Date':<20} {'Status':<15} {'Items':<30} {'Agent':<15}")
#         print("-" * 100)
#         for order in user_orders:
#             items = ", ".join([f"{item} (x{quantity})" for item, quantity in order["items"].items()])
#             agent = order.get("agent_name", "N/A")
#             print(f"{order['order_date']:<10} {order['order_date']:<20} {order['status']:<15} {items:<30} {agent:<15}")
#         print("-" * 100)
import json
import os
import time
import threading
from datetime import datetime
from coupons import CouponDatabase
from items import ItemDatabase

# Filepath for the JSON database
ORDER_DB_FILE = 'orders.json'
CART_DB_FILE = 'cart.json'
AGENT_DB_FILE = 'delivery_agents.json'
COUPON_DB_FILE = 'coupons.json'
ITEM_DB_FILE = 'items.json'

class OrderDatabase:
    def __init__(self, filepath):
        self.filepath = filepath
        self.data = self.load_order_data()
        self.agent_data = self.load_agent_data()
        self.coupon_db = CouponDatabase(COUPON_DB_FILE)
        self.item_db = ItemDatabase(ITEM_DB_FILE)

    def load_order_data(self):
        if not os.path.exists(self.filepath):
            with open(self.filepath, 'w') as f:
                json.dump({}, f)
        
        with open(self.filepath, 'r') as f:
            return json.load(f)

    def load_agent_data(self):
        if not os.path.exists(AGENT_DB_FILE):
            with open(AGENT_DB_FILE, 'w') as f:
                json.dump({"agents": []}, f)
        
        with open(AGENT_DB_FILE, 'r') as f:
            return json.load(f)

    def save_order_data(self):
        with open(self.filepath, 'w') as f:
            json.dump(self.data, f, indent=4)

    def save_agent_data(self):
        with open(AGENT_DB_FILE, 'w') as f:
            json.dump(self.agent_data, f, indent=4)

    def assign_delivery_agent(self):
        for agent in self.agent_data["agents"]:
            if agent["status"] == "Available":
                agent["status"] = "Unavailable"
                self.save_agent_data()
                return agent
        return None

    def update_order_status(self, order_id, status):
        self.data[order_id]["status"] = status
        self.save_order_data()

    def complete_delivery(self, order_id, agent_id):
        time.sleep(30)
        self.update_order_status(order_id, "Delivered")
        for agent in self.agent_data["agents"]:
            if agent["id"] == agent_id:
                agent["status"] = "Available"
                self.save_agent_data()
                break
        # Generate coupons based on the number of completed orders
        order = self.data[order_id]
        username = order["username"]
        completed_orders = sum(1 for order in self.data.values() if order["status"] == "Delivered" and order["username"] == username)
        self.coupon_db.generate_coupons(username, completed_orders)

    def place_order(self, username, cart_data, user_type, apply_coupon=None):
        if username not in cart_data or not cart_data[username]:
            print("Your cart is empty. Cannot place order.")
            return

        agent = self.assign_delivery_agent()
        if not agent:
            print("Currently no delivery agent is available. Please place the order after a while.")
            return

        order_id = str(len(self.data) + 1)
        order_details = {
            "username": username,
            "items": cart_data[username],
            "order_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "Delivering",
            "agent_id": agent["id"],
            "agent_name": agent["name"]
        }

        items = self.item_db.get_items()
        total_price = 0
        for item_name, quantity in cart_data[username].items():
            item = next((item for item in items if item["name"].lower() == item_name.lower()), None)
            if item:
                price = item["individual_price"] if user_type == "individual" else item["retail_price"]
                total_price += price * quantity

        if apply_coupon:
            discount = apply_coupon["discount"]
            discounted_price = total_price * (1 - discount / 100)
            order_details["discount"] = discount
            order_details["total_price"] = discounted_price
            self.coupon_db.avail_coupon(username, discount)
            print(f"Coupon applied! Total price after {discount}% discount: {discounted_price}")
        else:
            order_details["total_price"] = total_price

        self.data[order_id] = order_details
        self.save_order_data()
        print("Order placed successfully!")

        # Start a thread to simulate delivery
        threading.Thread(target=self.complete_delivery, args=(order_id, agent["id"])).start()

    def view_orders(self, username):
        user_orders = [order for order in self.data.values() if order["username"] == username]
        if not user_orders:
            print("No orders found.")
            return

        print(f"{'Order ID':<10} {'Order Date':<20} {'Status':<15} {'Items':<30} {'Agent':<15} {'Total Price':<15}")
        print("-" * 100)
        for order in user_orders:
            items = ", ".join([f"{item} (x{quantity})" for item, quantity in order["items"].items()])
            agent = order.get("agent_name", "N/A")
            total_price = order.get("total_price", "N/A")
            print(f"{order['order_date']:<10} {order['order_date']:<20} {order['status']:<15} {items:<30} {agent:<15} {total_price:<15}")
        print("-" * 100)