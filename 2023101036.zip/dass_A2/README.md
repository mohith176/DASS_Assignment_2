## Instructions to run unittests in Q1
### go to q1/testcases
#### run python3 unit_tests.py

## Instructions to run pytests in Q3
### go to q3/testcases
#### run pytest test_pytests.py -s -v