import unittest
import sqlite3
import os
import sys
import hashlib
from unittest.mock import patch, MagicMock, ANY

# Fix the import path to correctly point to the src directory where modules are located
src_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../src'))
sys.path.insert(0, src_dir)

# Import the modules 
try:
    from app import app
    from authenticate import authentication
    from cart import Cart
    from database import initialisation
    from home import Home
    from menu import Menu
    from order import Order
except ImportError as e:
    print(f"Import error: {e}")
    print(f"Looking for modules in: {src_dir}")
    print(f"Current sys.path: {sys.path}")
    raise


class TestApp(unittest.TestCase):
    @patch('builtins.input')
    @patch('app.app.after_choosing_customer')
    @patch('app.app.after_choosing_manager')
    def test_start(self, mock_manager, mock_customer, mock_input):
        # Test customer flow
        mock_input.return_value = '1'
        app.start()
        mock_customer.assert_called_once()
        mock_manager.assert_not_called()
        
        # Reset mocks
        mock_customer.reset_mock()
        mock_manager.reset_mock()
        
        # Test manager flow
        mock_input.return_value = '2'
        app.start()
        mock_customer.assert_not_called()
        mock_manager.assert_called_once()
        
        # Reset mocks
        mock_customer.reset_mock()
        mock_manager.reset_mock()
        
        # Test exit
        mock_input.return_value = '3'
        with patch('builtins.print') as mock_print:
            app.start()
            mock_print.assert_any_call("Goodbye!")
        
        # Test invalid choice
        mock_input.return_value = 'invalid'
        with patch('app.app.start') as mock_start:
            app.start()
            mock_start.assert_called_once()
    
    @patch('builtins.input')
    @patch('authenticate.authentication.register')
    @patch('authenticate.authentication.login')
    def test_after_choosing_customer(self, mock_login, mock_register, mock_input):
        # Test register
        mock_input.return_value = '1'
        app.after_choosing_customer()
        mock_register.assert_called_once()
        mock_login.assert_not_called()
        
        # Reset mocks
        mock_register.reset_mock()
        mock_login.reset_mock()
        
        # Test login
        mock_input.return_value = '2'
        app.after_choosing_customer()
        mock_register.assert_not_called()
        mock_login.assert_called_once()
        
        # Test exit
        mock_input.return_value = '3'
        with patch('builtins.print') as mock_print:
            app.after_choosing_customer()
            mock_print.assert_any_call("Goodbye!")
        
        # Test invalid choice
        mock_input.return_value = 'invalid'
        with patch('app.app.after_choosing_customer') as mock_after_choosing:
            app.after_choosing_customer()
            mock_after_choosing.assert_called_once()
    
    @patch('builtins.input')
    @patch('home.Home.manager_homepage')
    def test_after_choosing_manager(self, mock_homepage, mock_input):
        # Test correct PIN
        mock_input.return_value = '1234'
        app.after_choosing_manager()
        mock_homepage.assert_called_once()
        
        # Test exit
        mock_input.return_value = 'E'
        with patch('builtins.print') as mock_print:
            app.after_choosing_manager()
            mock_print.assert_any_call("Goodbye!")
        
        # Test invalid PIN
        mock_input.return_value = 'invalid'
        with patch('app.app.after_choosing_manager') as mock_after_choosing:
            app.after_choosing_manager()
            mock_after_choosing.assert_called_once()


class TestAuthentication(unittest.TestCase):
    @patch('sqlite3.connect')
    @patch('builtins.input')
    @patch('home.Home.customer_homepage')
    def test_register(self, mock_homepage, mock_input, mock_connect):
        # Setup mock database connection
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.lastrowid = 1
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn
        
        # Setup mock inputs
        mock_input.side_effect = ['John Doe', '123 Street', 'password123', 'john@example.com', '1234567890']
        
        # Test registration
        with patch('builtins.print') as mock_print:
            authentication.register()
            mock_cursor.execute.assert_called_with('''INSERT INTO customers (name, address, password, email, phone) 
                  VALUES (?, ?, ?, ?, ?)''', ('John Doe', '123 Street', hashlib.sha256('password123'.encode()).hexdigest(), 'john@example.com', '1234567890'))
            mock_conn.commit.assert_called_once()
            mock_print.assert_any_call("Registration successful! Your customer ID is 1")
            mock_homepage.assert_called_once()
    
    @patch('sqlite3.connect')
    @patch('builtins.input')
    @patch('home.Home.customer_homepage')
    def test_login_success(self, mock_homepage, mock_input, mock_connect):
        # Setup mock database connection
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.fetchone.return_value = [1]
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn
        
        # Setup mock inputs
        mock_input.side_effect = ['john@example.com', 'password123']
        
        # Test successful login
        with patch('builtins.print') as mock_print:
            authentication.login()
            mock_cursor.execute.assert_called_with('''SELECT id FROM customers WHERE email = ? AND password = ?''', 
                                                ('john@example.com', hashlib.sha256('password123'.encode()).hexdigest()))
            mock_print.assert_any_call("Login successful! Your customer ID is 1")
            mock_homepage.assert_called_once()


class TestCart(unittest.TestCase):
    @patch('sqlite3.connect')
    @patch('builtins.input')
    def test_add_to_cart(self, mock_input, mock_connect):
        # Setup mock database connection
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.fetchone.side_effect = [True, True]  # Customer and item exist
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn
        
        # Setup mock inputs
        mock_input.side_effect = ['1', '2', '3']  # customer_id, item_id, quantity
        
        # Test adding to cart
        with patch('builtins.print') as mock_print:
            Cart.add_to_cart()
            mock_cursor.execute.assert_any_call('''INSERT INTO cart (customer_id, item_id, quantity) 
                          VALUES (?, ?, ?)''', ('1', '2', '3'))
            mock_conn.commit.assert_called_once()
            mock_print.assert_any_call("Item added to cart!")
    
    @patch('sqlite3.connect')
    @patch('builtins.input')
    def test_view_cart(self, mock_input, mock_connect):
        # Setup mock database connection
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        # Update price format to include "rupees"
        mock_cursor.fetchall.return_value = [(1, 'Pizza', '45 rupees', 2, 90.0)]
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn
        
        # Setup mock inputs
        mock_input.return_value = '1'  # customer_id
        
        # Test viewing cart
        with patch('builtins.print') as mock_print:
            Cart.view_cart()
            mock_cursor.execute.assert_called_with('''
            SELECT cart.item_id, menu.item_name, menu.price, cart.quantity, (menu.price * cart.quantity) as total_price
            FROM cart
            JOIN menu ON cart.item_id = menu.id
            WHERE cart.customer_id = ?
        ''', ('1',))
            mock_print.assert_any_call("Your cart:")
    
    @patch('sqlite3.connect')
    @patch('builtins.input')
    def test_remove_from_cart(self, mock_input, mock_connect):
        # Setup mock database connection
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.fetchone.side_effect = [True, [2], None]  # Customer exists, current quantity, done
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn
        
        # Setup mock inputs
        mock_input.side_effect = ['1', '2', '2']  # customer_id, item_id, quantity (equal to current)
        
        # Test removing from cart (entire item case)
        with patch('builtins.print') as mock_print:
            Cart.remove_from_cart()
            mock_cursor.execute.assert_any_call('''DELETE FROM cart WHERE customer_id = ? AND item_id = ?''', ('1', '2'))
            mock_conn.commit.assert_called_once()
            mock_print.assert_any_call("Item quantity updated in cart!")


class TestDatabase(unittest.TestCase):
    @patch('sqlite3.connect')
    def test_create_connection(self, mock_connect):
        # Setup mock database connection
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn
        
        initialisation.create_connection()
        
        # Test that all tables are created
        mock_connect.assert_called_with("food_delivery.db")
        self.assertEqual(mock_cursor.execute.call_count, 5)
        mock_conn.commit.assert_called_once()
        mock_conn.close.assert_called_once()


class TestMenu(unittest.TestCase):
    @patch('sqlite3.connect')
    def test_view_menu(self, mock_connect):
        # Setup mock database connection with price format including "rupees"
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = [(1, 'Pizza', 'Delicious pizza', '45 rupees', 'Available')]
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn
        
        # Test viewing menu
        with patch('builtins.print') as mock_print:
            Menu.view_menu()
            mock_cursor.execute.assert_called_with('''SELECT * FROM menu''')
            mock_print.assert_any_call("Menu")
    
    @patch('sqlite3.connect')
    @patch('builtins.input')
    def test_remove_items_from_menu(self, mock_input, mock_connect):
        # Setup mock database connection
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.rowcount = 1  # Item exists
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn
        
        # Setup mock inputs
        mock_input.return_value = 'Pizza'
        
        # Test removing items from menu
        with patch('builtins.print') as mock_print:
            Menu.remove_items_from_menu()
            mock_cursor.execute.assert_called_with('''DELETE FROM menu WHERE item_name = ?''', ('Pizza',))
            mock_conn.commit.assert_called_once()
            mock_print.assert_any_call("Item removed from menu!")
    
    @patch('sqlite3.connect')
    @patch('builtins.input')
    def test_update_items_from_menu(self, mock_input, mock_connect):
        # Setup mock database connection
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn
        
        # Setup mock inputs for item name update
        mock_input.side_effect = ['1', '1', 'New Pizza']
        
        # Test updating item name
        with patch('builtins.print') as mock_print:
            Menu.update_items_from_menu()
            mock_cursor.execute.assert_called_with('''UPDATE menu SET item_name = ? WHERE id = ?''', ('New Pizza', '1'))
            mock_conn.commit.assert_called_once()
            mock_print.assert_any_call("Item name updated!")


class TestOrder(unittest.TestCase):
    @patch('sqlite3.connect')
    @patch('builtins.input')
    def test_view_delivery_agents(self, mock_input, mock_connect):
        # Setup mock database connection
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = [(1, 'John Doe', 'Available')]
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn
        
        # Test viewing delivery agents
        with patch('builtins.print') as mock_print:
            Order.view_delivery_agents()
            mock_cursor.execute.assert_called_with('''SELECT id, name, status FROM delivery_agents''')
            mock_print.assert_any_call("Delivery Agents")
    
    @patch('sqlite3.connect')
    @patch('builtins.input')
    def test_manager_view_orders(self, mock_input, mock_connect):
        # Setup mock database connection
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = [(1, 'John Doe', 'Pizza x2', 'takeaway', 'Accepted', 90.0, None, None)]
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn
        
        # Test viewing orders as manager
        with patch('builtins.print') as mock_print:
            Order.manager_view_orders()
            mock_cursor.execute.assert_called_with('''SELECT * FROM orders''')
            mock_print.assert_any_call("Orders")
    
    @patch('sqlite3.connect')
    @patch('builtins.input')
    def test_customer_view_orders(self, mock_input, mock_connect):
        # Setup mock database connection
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = [(1, 'Pizza x2', 'takeaway', 'Accepted', 90.0, None, None)]
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn
        
        # Setup mock inputs
        mock_input.return_value = '1'
        
        # Test viewing orders as customer
        with patch('builtins.print') as mock_print:
            Order.customer_view_orders()
            mock_cursor.execute.assert_called_with('''
            SELECT id, order_details, order_type, status, price, delivery_time, delivery_agent
            FROM orders
            WHERE customer_name = (SELECT name FROM customers WHERE id = ?)
        ''', ('1',))
            mock_print.assert_any_call("Your orders:")


class TestHome(unittest.TestCase):
    @patch('builtins.input')
    @patch('menu.Menu.view_menu')
    @patch('home.Home.nav1')
    def test_customer_homepage_view_menu(self, mock_nav1, mock_view_menu, mock_input):
        # Test view menu option
        mock_input.return_value = '1'
        Home.customer_homepage()
        mock_view_menu.assert_called_once()
        mock_nav1.assert_called_once()
    
    @patch('builtins.input')
    @patch('order.Order.customer_view_orders')
    @patch('home.Home.nav3')
    def test_customer_homepage_view_orders(self, mock_nav3, mock_view_orders, mock_input):
        # Test view orders option
        mock_input.return_value = '2'
        Home.customer_homepage()
        mock_view_orders.assert_called_once()
        mock_nav3.assert_called_once()
    
    @patch('builtins.input')
    @patch('app.app.start')
    def test_customer_homepage_logout(self, mock_start, mock_input):
        # Test logout option
        mock_input.return_value = '3'
        with patch('builtins.print') as mock_print:
            Home.customer_homepage()
            mock_print.assert_any_call("Logout")
            mock_start.assert_called_once()
    
    @patch('builtins.input')
    def test_customer_homepage_exit(self, mock_input):
        # Test exit option
        mock_input.return_value = '4'
        with patch('builtins.print') as mock_print:
            Home.customer_homepage()
            mock_print.assert_any_call("Goodbye!")


if __name__ == '__main__':
    unittest.main(verbosity=2)