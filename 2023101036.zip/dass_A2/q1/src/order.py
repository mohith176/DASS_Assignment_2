import sqlite3
import time
import threading
import sys


class Order:
    def place_order():
        conn = sqlite3.connect("food_delivery.db")
        cursor = conn.cursor()

        customer_id = input("Enter your customer id: ")
        cursor.execute('''SELECT id FROM customers WHERE id = ?''', (customer_id,))
        if not cursor.fetchone():
            print("Invalid customer ID. Please try again.")
            conn.close()
            return

        cursor.execute('''
            SELECT cart.item_id, menu.item_name, menu.price, cart.quantity
            FROM cart
            JOIN menu ON cart.item_id = menu.id
            WHERE cart.customer_id = ?
        ''', (customer_id,))
        cart_items = cursor.fetchall()

        if not cart_items:
            print("Your cart is empty!")
            conn.close()
            return

        order_details = ""
        total_price = 0
        for item in cart_items:
            item_id, item_name, price, quantity = item
            price = float(price.split()[0])  
            quantity = int(quantity)
            order_details += f"{item_name} (x{quantity}), "
            total_price += price * quantity

        order_details = order_details.rstrip(", ")
        print("1. Home Delivery")
        print("2. Takeaway")
        order_type = input("Enter your choice: ")
        if order_type == '1':
            order_type = 'home delivery'
        elif order_type == '2':
            order_type = 'takeaway'
        else:
            print("Invalid choice. Please try again.")
            conn.close()
            return


        if order_type == "takeaway":
            cursor.execute('''
                INSERT INTO orders (customer_name, order_details, order_type, status, price)
                VALUES ((SELECT name FROM customers WHERE id = ?), ?, ?, 'Accepted', ?)
            ''', (customer_id, order_details, order_type, total_price))
            cursor.execute('''DELETE FROM cart WHERE customer_id = ?''', (customer_id,))
            conn.commit()
            print("Order placed successfully! Your order is accepted.")
            conn.close()
            from home import Home
            Home.nav3()  
            return

        cursor.execute('''SELECT id, name FROM delivery_agents WHERE status = 'Available' LIMIT 1''')
        delivery_agent = cursor.fetchone()
        if not delivery_agent:
            print("No delivery agents available right now. Please try after a while.")
            conn.close()
            return

        delivery_agent_id, delivery_agent_name = delivery_agent
        cursor.execute('''
            INSERT INTO orders (customer_name, order_details, order_type, status, price, delivery_agent)
            VALUES ((SELECT name FROM customers WHERE id = ?), ?, ?, 'Delivering', ?, ?)
        ''', (customer_id, order_details, order_type, total_price, delivery_agent_name))
        order_id = cursor.lastrowid
        cursor.execute('''UPDATE delivery_agents SET status = 'Unavailable' WHERE id = ?''', (delivery_agent_id,))
        cursor.execute('''DELETE FROM cart WHERE customer_id = ?''', (customer_id,))
        conn.commit()
        conn.close()

        print(f"Order placed successfully! Your order is being delivered by {delivery_agent_name}.")

        def update_order_status():
            for remaining in range(30, 0, -1):
                sys.stdout.write(f"\rTime remaining for delivery: {remaining} seconds")
                sys.stdout.flush()
                time.sleep(1)
            conn = sqlite3.connect("food_delivery.db")
            cursor = conn.cursor()
            cursor.execute('''UPDATE orders SET status = 'Delivered' WHERE id = ?''', (order_id,))
            cursor.execute('''UPDATE delivery_agents SET status = 'Available' WHERE id = ?''', (delivery_agent_id,))
            conn.commit()
            conn.close()
            print("\nOrder delivered successfully!")
            from home import Home
            Home.nav3()  

        threading.Thread(target=update_order_status).start()

    def customer_view_orders():
        customer_id = input("Enter your customer id: ")
        conn = sqlite3.connect("food_delivery.db")
        cursor = conn.cursor()
        cursor.execute('''
            SELECT id, order_details, order_type, status, price, delivery_time, delivery_agent
            FROM orders
            WHERE customer_name = (SELECT name FROM customers WHERE id = ?)
        ''', (customer_id,))
        result = cursor.fetchall()
        conn.close()

        if result:
            print("Your orders:")
            print("{:<10} {:<30} {:<10} {:<10} {:<10} {:<20} {:<20}".format("Order ID", "Order Details", "Order Type", "Status", "Price", "Delivery Time", "Delivery Agent"))
            print("-" * 110)
            for row in result:
                order_id, order_details, order_type, status, price, delivery_time, delivery_agent = row
                order_details = order_details or ""
                order_type = order_type or ""
                status = status or ""
                price = price or 0
                delivery_time = delivery_time or ""
                delivery_agent = delivery_agent or ""
                print("{:<10} {:<30} {:<10} {:<10} {:<10} {:<20} {:<20}".format(order_id, order_details, order_type, status, price, delivery_time, delivery_agent))
            print("-" * 110)
        else:
            print("No orders found!")


    def view_delivery_agents():
        conn = sqlite3.connect("food_delivery.db")
        cursor = conn.cursor()
        cursor.execute('''SELECT id, name, status FROM delivery_agents''')
        result = cursor.fetchall()
        conn.close()

        print("Delivery Agents")
        print("{:<10} {:<30} {:<10}".format("ID", "Name", "Status"))
        print("-" * 50)
        for row in result:
            agent_id, agent_name, status = row
            print("{:<10} {:<30} {:<10}".format(agent_id, agent_name, status))
        print("-" * 50)

    def manager_view_orders():
        conn = sqlite3.connect("food_delivery.db")
        cursor = conn.cursor()
        cursor.execute('''SELECT * FROM orders''')
        result = cursor.fetchall()
        conn.close()

        print("Orders")
        print("{:<10} {:<30} {:<50} {:<10} {:<10} {:<20} {:<20}".format("ID", "Customer Name", "Order Details", "Order Type", "Status", "Price", "Delivery Agent"))
        print("-" * 150)
        for row in result:
            order_id, customer_name, order_details, order_type, status, price, delivery_time, delivery_agent = row
            order_details = order_details or ""
            order_type = order_type or ""
            status = status or ""
            price = price or 0
            delivery_time = delivery_time or ""
            delivery_agent = delivery_agent or ""
            print("{:<10} {:<30} {:<50} {:<10} {:<10} {:<20} {:<20}".format(order_id, customer_name, order_details, order_type, status, price, delivery_agent))
        print("-" * 150)