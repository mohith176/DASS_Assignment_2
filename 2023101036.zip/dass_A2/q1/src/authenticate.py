import sqlite3
import hashlib
from home import Home

class authentication:
    def register():
        print("Enter your details to register")
        name = input("Enter your name: ")
        address = input("Enter your address: ")
        password = input("Enter your password: ")
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        email = input("Enter your email: ")
        phone = input("Enter your phone: ")
        conn = sqlite3.connect("food_delivery.db")
        cursor = conn.cursor()
        cursor.execute('''INSERT INTO customers (name, address, password, email, phone) 
                  VALUES (?, ?, ?, ?, ?)''', (name, address, hashed_password, email, phone))
        conn.commit()
        customer_id = cursor.lastrowid
        conn.close()
        print(f"Registration successful! Your customer ID is {customer_id}")
        print("Do not forget your customer ID!, you will need it to do anything in the system.")
        Home.customer_homepage()

    def login():
        email = input("Enter your email: ")
        password = input("Enter your password: ")
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        conn = sqlite3.connect("food_delivery.db")
        cursor = conn.cursor()
        cursor.execute('''SELECT id FROM customers WHERE email = ? AND password = ?''', (email, hashed_password))
        result = cursor.fetchone()
        conn.close()

        if result:
            customer_id = result[0]
            print(f"Login successful! Your customer ID is {customer_id}")
            print("Do not forget your customer ID!, you will need it to do anything in the system.")
            Home.customer_homepage()
        else:
            print("Invalid email or password. Please try again.")
            authentication.login()

    