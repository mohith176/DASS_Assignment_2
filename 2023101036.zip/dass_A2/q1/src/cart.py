import sqlite3

class Cart:
    def add_to_cart():
        conn = sqlite3.connect("food_delivery.db")
        cursor = conn.cursor()

        while True:
            customer_id = input("Enter your customer id: ")
            cursor.execute('''SELECT id FROM customers WHERE id = ?''', (customer_id,))
            if cursor.fetchone():
                break
            else:
                print("Invalid customer ID. Please try again.")

        while True:
            item_id = input("Enter the item id you want to add to cart: ")
            cursor.execute('''SELECT id FROM menu WHERE id = ?''', (item_id,))
            if cursor.fetchone():
                break
            else:
                print("Invalid item ID. Please try again.")

        quantity = input("Enter the quantity you want to add to cart: ")
        cursor.execute('''INSERT INTO cart (customer_id, item_id, quantity) 
                          VALUES (?, ?, ?)''', (customer_id, item_id, quantity))
        conn.commit()
        conn.close()
        print("Item added to cart!")

    def view_cart():
        customer_id = input("Enter your customer id: ")
        conn = sqlite3.connect("food_delivery.db")
        cursor = conn.cursor()
        cursor.execute('''
            SELECT cart.item_id, menu.item_name, menu.price, cart.quantity, (menu.price * cart.quantity) as total_price
            FROM cart
            JOIN menu ON cart.item_id = menu.id
            WHERE cart.customer_id = ?
        ''', (customer_id,))
        result = cursor.fetchall()
        conn.close()
        
        if result:
            print("Your cart:")
            print("{:<10} {:<30} {:<10} {:<10} {:<10}".format("Item ID", "Item Name", "Price", "Quantity", "Total"))
            print("-" * 70)
            total_amount = 0
            for row in result:
                item_id, item_name, price, quantity, total_price = row
                print("{:<10} {:<30} {:<10} {:<10} {:<10}".format(item_id, item_name, price, quantity, total_price))
                total_amount += total_price
            print("-" * 70)
            print(f"Total Amount: {total_amount}")
        else:
            print("Cart is empty!")

    def remove_from_cart():
        conn = sqlite3.connect("food_delivery.db")
        cursor = conn.cursor()

        while True:
            customer_id = input("Enter your customer id: ")
            cursor.execute('''SELECT id FROM customers WHERE id = ?''', (customer_id,))
            if cursor.fetchone():
                break
            else:
                print("Invalid customer ID. Please try again.")

        while True:
            item_id = input("Enter the item id you want to remove from cart: ")
            cursor.execute('''SELECT quantity FROM cart WHERE customer_id = ? AND item_id = ?''', (customer_id, item_id))
            result = cursor.fetchone()
            if result:
                current_quantity = result[0]
                break
            else:
                print("Invalid item ID or item not in cart. Please try again.")

        while True:
            quantity_to_remove = int(input("Enter the quantity you want to remove from cart: "))
            if 0 < quantity_to_remove <= current_quantity:
                break
            else:
                print(f"Invalid quantity. Please enter a value between 1 and {current_quantity}.")

        if quantity_to_remove == current_quantity:
            cursor.execute('''DELETE FROM cart WHERE customer_id = ? AND item_id = ?''', (customer_id, item_id))
        else:
            new_quantity = current_quantity - quantity_to_remove
            cursor.execute('''UPDATE cart SET quantity = ? WHERE customer_id = ? AND item_id = ?''', (new_quantity, customer_id, item_id))

        conn.commit()
        conn.close()
        print("Item quantity updated in cart!")