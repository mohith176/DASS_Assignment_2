from menu import Menu
from cart import Cart
from order import Order
class Home:
    def customer_homepage():
        print("Home Page")
        print("1. View Menu")
        print("2. View order history")
        print("3. Logout")
        print("4. Exit")
        choice = input("Enter your choice: ")
        if choice == '1':
            Menu.view_menu()
            Home.nav1()
        elif choice == '2':
            Order.customer_view_orders()
            Home.nav3()
        elif choice == '3':
            print("Logout")
            from app import app
            app.start()
        elif choice == '4':
            print("Goodbye!")
        else:
            print("Invalid choice. Please try again.")
            Home.customer_homepage()


    def manager_homepage():
        print("What would you like to do?")
        print("(1) Update menu")
        print("(2) View orders")
        print("(3) View Delivery Agents")
        print("(4) Exit")
        choice = input("Enter your choice: ")
        if choice == '1':
            Menu.manager_menu_homepage()
            Home.manager_homepage()
        elif choice == '2':
            Order.manager_view_orders()
            Home.manager_homepage()
        elif choice == '3':
            Order.view_delivery_agents()
            Home.manager_homepage()
        elif choice == '4':
            print("Goodbye!")
        else:
            print("Invalid choice. Please try again.")
            Home.manager_homepage()

    def nav1():
         while(1):
            print("Home(H)   Add to cart(A)   Remove from cart(R)   View cart(V)    Exit(E)")
            choice = input("Enter your choice: ")
            if choice == 'H':
                Home.customer_homepage()
                break
            elif choice == 'A':
                print("Cart before adding")
                Cart.view_cart()
                Cart.add_to_cart()
                print("Cart after adding")
                Cart.view_cart()
                Home.nav2()
                break
            elif choice == 'R':
                print("Cart before removing")
                Cart.view_cart()
                Cart.remove_from_cart()
                print("Cart after removing")
                Cart.view_cart()
                Home.nav2()
                break
            elif choice == 'V':
                Cart.view_cart()
                Home.nav2()
                break
            elif choice == 'E':
                print("Goodbye!")
                break
            else:
                print("Invalid choice. Please try again.")

    def nav2():
            while(1):
                print("Home(H)    Place_Order(P)    Exit(E)")
                choice = input("Enter your choice: ")
                if choice == 'H':
                    Home.customer_homepage()
                    break
                elif choice == 'P':
                    Order.place_order()
                    # Home.nav3()
                    break
                elif choice == 'E':
                    print("Goodbye!")
                    break
                else:
                    print("Invalid choice. Please try again.")

    def nav3():
        while(1):
            print("Home(H)    Exit(E)")
            choice = input("Enter your choice: ")
            if choice == 'H':
                Home.customer_homepage()
                break
            elif choice == 'E':
                print("Goodbye!")
                break
            else:
                print("Invalid choice. Please try again.")