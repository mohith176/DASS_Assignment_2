import sqlite3
import hashlib
from database import initialisation
from authenticate import authentication
from menu import Menu
from home import Home

class app:
    def after_choosing_customer():
        print("What would you like to do?")
        print("(1) Register")
        print("(2) Login")
        print("(3) Exit")
        choice = input("Enter your choice: ")
        if choice == '1':
            authentication.register()
        elif choice == '2':
            authentication.login()
        elif choice == '3':
            print("Goodbye!")
        else:
            print("Invalid choice. Please try again.")
            app.after_choosing_customer()
    
    def after_choosing_manager():
        print("Enter 'E' to exit")
        print("Please enter your admin PIN")
        pin = input("Enter your PIN: ")
        if pin == '1234':
            Home.manager_homepage()
        elif pin == 'E':
            print("Goodbye!")
        else:
            print("Invalid PIN. Please try again.")
            app.after_choosing_manager()
        

    def start():
        print("Welcome to the online food ordering system!")
        print("Are you a customer or a manager?")
        print("(1) Customer")
        print("(2) Manager")
        print("(3) Exit")
        choice = input("Enter your choice: ")
        if choice == '1':
            app.after_choosing_customer()
        elif choice == '2':
            app.after_choosing_manager()
        elif choice == '3':
            print("Goodbye!")
        else:
            print("Invalid choice. Please try again.")
            app.start()





    
if __name__ == '__main__':
    
    initialisation.create_connection()
    app.start()