import sqlite3

class Menu:
    def view_menu():
        conn = sqlite3.connect("food_delivery.db")
        cursor = conn.cursor()
        cursor.execute('''SELECT * FROM menu''')
        result = cursor.fetchall()
        conn.close()
        print("Menu")
        print("{:<10} {:<30} {:<50} {:<10} {:<15}".format("ID", "Item Name", "Description", "Price", "Status"))
        print("-" * 115)
        for row in result:
            item_id, item_name, item_description, price, status = row
            print("{:<10} {:<30} {:<50} {:<10} {:<15}".format(item_id, item_name, item_description, price, status))
        print("-" * 115)
    


    def add_items_to_menu():
        print("Add items to menu")
        item_name = input("Enter item name: ")
        item_description = input("Enter item description: ")
        price = input("Enter price: ")
        conn = sqlite3.connect("food_delivery.db")
        cursor = conn.cursor()
        cursor.execute('''INSERT INTO menu (item_name, item_description, price) 
                  VALUES (?, ?, ?)''', (item_name, item_description, price))
        conn.commit()
        conn.close()
        print("Item added to menu!")



    def remove_items_from_menu():
        print("Remove items from menu")
        item_name = input("Enter item name: ")
        conn = sqlite3.connect("food_delivery.db")
        cursor = conn.cursor()
        cursor.execute('''DELETE FROM menu WHERE item_name = ?''', (item_name,))
        if cursor.rowcount == 0:
            print("Item not found in menu.")
            conn.commit()  
            conn.close()
            return
        conn.commit()
        conn.close()
        print("Item removed from menu!")



    def update_items_from_menu():
        print("Choose an item to update")
        item_id = input("Enter item id: ")
        print("What would you like to update?")
        print("(1) Item name")
        print("(2) Item description")
        print("(3) Price")
        print("(4) Item status")
        choice = input("Enter your choice: ")


        if choice == '1':
            item_name = input("Enter new item name: ")
            conn = sqlite3.connect("food_delivery.db")
            cursor = conn.cursor()
            cursor.execute('''UPDATE menu SET item_name = ? WHERE id = ?''', (item_name, item_id))
            conn.commit()
            conn.close()
            print("Item name updated!")

        elif choice == '2':
            item_description = input("Enter new item description: ")
            conn = sqlite3.connect("food_delivery.db")
            cursor = conn.cursor()
            cursor.execute('''UPDATE menu SET item_description = ? WHERE id = ?''', (item_description, item_id))
            conn.commit()
            conn.close()
            print("Item description updated!")

        elif choice == '3':
            price = input("Enter new price: ")
            conn = sqlite3.connect("food_delivery.db")
            cursor = conn.cursor()
            cursor.execute('''UPDATE menu SET price = ? WHERE id = ?''', (price, item_id))
            conn.commit()
            conn.close()
            print("Price updated!")

        elif choice == '4':
            print("Choose new item status")
            print("(1) Available")
            print("(2) Unavailable")
            item_status = input("Enter new item status: ")
            if item_status == '1':
                item_status = 'Available'
            elif item_status == '2':
                item_status = 'Unavailable'
            conn = sqlite3.connect("food_delivery.db")
            cursor = conn.cursor()
            cursor.execute('''UPDATE menu SET item_status = ? WHERE id = ?''', (item_status, item_id))
            conn.commit()
            conn.close()
            print("Item status updated to " + item_status)

        else:
            print("Invalid choice. Please try again.")
            Menu.update_items_from_menu()

    def manager_menu_homepage():
        print("Menu Page")
        print("1. View Menu")
        print("2. Add items to menu")
        print("3. Remove items from menu")
        print("4. Update items from menu")
        print("5. Exit")
        choice = input("Enter your choice: ")
        if choice == '1':
            Menu.view_menu()
        elif choice == '2':
            Menu.view_menu()
            Menu.add_items_to_menu()
        elif choice == '3':
            Menu.view_menu()
            Menu.remove_items_from_menu()
        elif choice == '4':
            Menu.view_menu()
            Menu.update_items_from_menu()
        elif choice == '5':
            print("Goodbye!")
        else:
            print("Invalid choice. Please try again.")
            Menu.manager_menu_homepage()    