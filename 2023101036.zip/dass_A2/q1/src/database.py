import sqlite3

class initialisation:
    def create_connection():
        conn = sqlite3.connect("food_delivery.db")
        cursor = conn.cursor()

        # Create tables

        cursor.execute('''CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            address TEXT NOT NULL,
            password TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL
        )''')

        cursor.execute('''CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name TEXT NOT NULL,
            order_details TEXT NOT NULL,
            order_type TEXT NOT NULL,
            status TEXT DEFAULT 'Pending',
            price REAL NOT NULL,
            delivery_time TEXT DEFAULT NULL,
            delivery_agent TEXT DEFAULT NULL
        )''')

        cursor.execute('''CREATE TABLE IF NOT EXISTS menu (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_name TEXT NOT NULL,
            item_description TEXT,
            price REAL NOT NULL,
            item_status TEXT DEFAULT 'Available'
        )''')

        cursor.execute('''CREATE TABLE IF NOT EXISTS cart (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL,
            item_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            FOREIGN KEY (customer_id) REFERENCES customers(id),
            FOREIGN KEY (item_id) REFERENCES menu(id)
        )''')
        
        cursor.execute('''CREATE TABLE IF NOT EXISTS delivery_agents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            status TEXT DEFAULT 'Available'
        )''')

        conn.commit()
        conn.close()